import unittest

class TestMain(unittest.unittest):
    pass

if __name__ == "__main__":
    unittest.main()
