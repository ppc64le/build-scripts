# Ignored invalid imported module

This test case asserts that the module's validation step succeeds as expected.
