# Exclusions
* Intentionally make the directory "a" so Gazelle visit this before "coarse_grained"
* Making sure that the exclusion here doesn't affect coarse_grained/bar/baz/hue.py