# Invalid imported module

This test case asserts that the module's validation step fails as expected.
