# From Imports

This test case simulates imports of the form:

```python
from foo import bar
```
