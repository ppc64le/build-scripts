# Subdir sources

This test case asserts that `py_library` targets are generated with sources from
subdirectories and that dependencies are added according to the target that the
imported source file belongs to.
