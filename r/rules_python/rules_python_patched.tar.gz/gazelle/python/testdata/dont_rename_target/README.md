# Don't rename target

This test case asserts that an existing target with a custom name doesn't get
renamed by the Gazelle extension.
