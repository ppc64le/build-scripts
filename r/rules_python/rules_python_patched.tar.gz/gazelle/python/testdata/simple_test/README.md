# Simple test

This test case asserts that a simple `py_test` is generated as expected.
