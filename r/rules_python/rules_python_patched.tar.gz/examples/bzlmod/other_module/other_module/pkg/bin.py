import sys

import absl

print("Python version:", sys.version)
print("Module 'absl':", absl)
