# compile_pip_requirements_test_from_external_repo

This test checks that compile_pip_requirements test can be run from external workspaces without invalidating the lock file.
